# Definition review: draft 2

Read the rubric and complete the blank definition form before viewing new
experimental outputs or other reviewers' suggested answers. Record actual reviewer
type, role, relationship and exposure in reviewer_metadata.csv. An author review or
AI contributor review is not automatically independent human validation.

This draft separates recovery forecasts, category certainty, presentation manner
and answer confidence. Assess their definitions and theoretical relevance. All
current controls contain attention models; determine what feature/contrast could
distinguish consciousness-report correspondence from ordinary causal description.
No primary consciousness endpoint, agreement threshold or powered protocol is frozen.

The blank rating CSV illustrates candidate dimensions only. It is not a request
to score reports yet. The package contains no reports, source states, condition
outcomes, completed R-C1 review, disposition answers, factual gold or human ratings.
Its illustrations are authored examples, excluded from reporter prompts/training.
Prior review remains preserved separately with its exposure record.

Return original comments and proposed changes; preserve revisions separately.
Missing judgments are not approval. Preparing these materials contacts nobody.
Relative links are rendered as plain labels; primary-source web links are retained.
