# Definition review v1

This packet is prepared first for author review. Record the actual reviewer role and prior exposure; author review is not independent validation.

Read FUNCTIONAL_REPORT_RUBRIC.md, then complete FUNCTIONAL_RUBRIC_REVIEW_FORM.md
and reviewer_metadata.csv. Review definitions and discriminating predictions
before opening factual cases or experimental prose. Referenced human studies
motivate measurement distinctions; they do not establish the machine theory.
No study outputs or preferred answers are included in this bundle. Later report
ratings use a separately frozen rubric and blinded inputs; the blank rating CSV
is included only to show the candidate dimensions.

Return unchanged original comments and any proposed revisions. A review may find
that the rubric needs revision or does not distinguish consciousness-related
reporting from ordinary description. Those outcomes must be retained. No review
has been completed by assembling this material, and no person has been contacted.
Local links are rendered as plain labels to keep this bundle standalone; external
primary-study links are retained. Exact original documents remain in the repository.
