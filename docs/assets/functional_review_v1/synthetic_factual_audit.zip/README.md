# Source-aware synthetic factual audit v1

This packet is prepared first for author review. Record the actual reviewer role and prior exposure; author review is not independent validation.

These 28 cases are author-written qualification-development examples, not machine
reports or experimental outcomes. Read the procedure and glossary, then inspect
cases.json or cases.md. Inventory quoted propositions in the blank claim CSV.
For the case explicitly requesting coverage, also fill the coverage CSV. Other
short cases assess proposition fidelity only, not full reporting coverage.
Record exact quotes and zero-based, end-exclusive character spans in the original
report (Unicode code points, not bytes). Keep omitted facts separate from false
assertions and source metadata separate from modeled-process claims.

No proposed answers or case-purpose labels appear here. Proposed author answers
are separate in the repository and require independent checking. Do not consult
them before initial annotations; disclose any exposure. This is procedural
withholding, not access control or a guarantee of blinding. Record disagreements
and ambiguous cases without forcing agreement with author expectations.

Complete reviewer_metadata.csv. Author annotations remain author annotations.
At least two independent factual auditors and a reviewed scoring protocol are
still needed for qualification. This packet does not certify reliability, human
agreement, a reporter or a consciousness-related interpretation.
