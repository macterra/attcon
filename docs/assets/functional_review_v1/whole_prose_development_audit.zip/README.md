# Whole-prose development audit v1

This packet is prepared first for author review. Record the actual reviewer role and prior exposure; author review is not independent validation.

This bundle contains unchanged reporter texts and reporter-visible payloads from
the completed v5 development study. It includes 24 calibration reports and 12
reports reserved for a subsequent whole-prose check. The split holds out an entire
visual/model pair from reviewer calibration. Multiple variants share episodes:
calibration covers four underlying episodes and the later check covers two.
These are correlated development records, not 36 independent trials.

The authors and earlier automated judges have already inspected these reports.
The later subset is held out from this reviewer's calibration, not fresh scientific
confirmation. Its selection is prospective for this review exercise and post-hoc
relative to v5. No new reporter calls, edits, retries or rescoring of v5 occur.

Read the procedure and the exact reporting_instruction for each case. Inventory
all quoted factual propositions, including extra assertions outside the requested
domains. Build the requested fact inventory from each payload/instruction before
reading that report; mark omission separately from contradiction. Write claims
and coverage into the blank CSVs, and record reviewer metadata.

Complete calibration before inspecting held_out_prose.json; disclose earlier
exposure. Preserve first-pass annotations before adjudication. Condition labels,
seeds, original IDs and previous scores are withheld from this bundle. Intrinsic
clues in unchanged prose and sources remain; opaque IDs do not ensure blinding.
Definitions/character review must occur separately, without these source records.
No ratings, qualification decision or expected score is supplied by this bundle.
